
public class Main {
    public static void main(String[] args) {
        Examen examen = new Examen();
        examen.Ejercicio1();

        }
    }
