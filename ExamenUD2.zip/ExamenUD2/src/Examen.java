import java.util.Scanner;
import java.util.Random;
public class Examen {
    public void Ejercicio1(){
        Scanner entrada = new Scanner(System.in);
        Random random = new Random();
        System.out.println("¿Piedra, papel o tijera? (p/a/t): ");
        String userinput = entrada.nextLine();
        int Random;
        int piedra = 0;
        int papel = 1;
        int tijera = 2;
        int puntuacion = 0;
        int puntuacion2=0;
        for(int i =1; i <=3;i++){
            System.out.println("Ronda " + i);
            Random = random.nextInt(3);
            if ("p".equals(userinput)){
                switch (Random) {
                    case 0:
                        System.out.println("El ordenador ha elegido: Piedra");
                        System.out.println("empate");
                        continue;
                    case 1:
                        System.out.println("El ordenador ha elegido: Papel");
                        System.out.println("¡Has perdido!");
                        puntuacion++;
                        break;
                    case 2:
                        System.out.println("El ordenador ha elegido: Tijera");
                        System.out.println("¡has ganado!");
                        puntuacion2++;
                        break;

                }

            }else if("a".equals(userinput)){
                switch (Random){
                    case 0:
                        System.out.println("El ordenador ha elegido: Piedra");
                        System.out.println("¡Has ganado!");
                        puntuacion2++;
                        break;
                    case 1:
                        System.out.println("El ordenador ha elegido: Papel");
                        System.out.println("Empate");
                        continue;
                    case 2:
                        System.out.println("El ordenador ha elegido: Tijera");
                        System.out.println("¡Has perdido!");
                        puntuacion++;
                        break;
                }
            }else if("t".equals(userinput)){
                switch (Random){
                    case 0:
                        System.out.println("El ordenador ha elegido: Piedra");
                        System.out.println("¡Has perdido!");
                        puntuacion++;
                        break;
                    case 1:
                        System.out.println("El ordenador ha elegido: Papel");
                        System.out.println("¡Has ganado!");
                        puntuacion2++;
                        break;
                    case 2:
                        System.out.println("El ordenador ha elegido: Tijera");
                        System.out.println("Empate");
                        continue;
                }
            }
            System.out.println("Marcador actual (PC-Usuario): " + puntuacion + "-" + puntuacion2);
        }
        if (puntuacion>puntuacion2){
            System.out.println("¡Ha ganado la maquina!");
        }else if (puntuacion2>puntuacion) {
            System.out.println("¡Ha ganado el usuario!");
        }
    }
    public void Ejercicio2(){
        Scanner entrada = new Scanner(System.in);
        System.out.println("Dame tu año de nacimiento: "); //pido el input al usuario
        int nacimiento = entrada.nextInt();
        int anyohoy = 2025;
        int edad=anyohoy - nacimiento; //Calculo la edad que tiene y consigo bucles para el loop
        if (nacimiento >1900 && anyohoy>nacimiento){//compruebo que no me pongan menores de 1900 o mayores de 2024
            for (int i = 0; i<edad; i++){  //Tremendo bucle
                System.out.println(nacimiento++ + "- edad: " + i );
            }
        }else{
            System.out.println("inroduce un año entra 1900 y " + anyohoy);
        }
    }
}

